module.exports = {
  name: "menu",
  description: "Affiche le menu des commandes",
  execute: async ({ reply }) => {
    await reply(
      "╭━━━〔 𝐋𝐎𝐍𝐄𝐖𝐎𝐋𝐅-𝐌𝐃 〕━━━╮\n" +
      "┃\n" +
      "┃ 𝐌𝐄𝐍𝐔 𝐏𝐑𝐈𝐍𝐂𝐈𝐏𝐀𝐋\n" +
      "┃\n" +
      "┃ ➤ 𝐌𝐞𝐧𝐮\n" +
      "┃ ➤ 𝐎𝐰𝐧𝐞𝐫\n" +
      "┃ ➤ 𝐊𝐢𝐜𝐤\n" +
      "┃ ➤ 𝐓𝐚𝐠𝐚𝐥𝐥\n" +
      "┃\n" +
      "╰━━━━━━━━━━━━━━━━━━━━━━╯"
    );
  }
};
