module.exports = {
  name: "tagall",
  description: "Mentionne les membres d'un groupe",
  adminOnly: true,
  execute: async ({ reply }) => {
    await reply(
      "╭━━〔 𝐓𝐀𝐆𝐀𝐋𝐋 〕━━╮\n" +
      "┃ 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐞 𝐝𝐞́𝐭𝐞𝐜𝐭𝐞́𝐞.\n" +
      "┃ 𝐋𝐚 𝐥𝐨𝐠𝐢𝐪𝐮𝐞 𝐝𝐞 𝐦𝐞𝐧𝐭𝐢𝐨𝐧 𝐝𝐨𝐢𝐭 𝐞̂𝐭𝐫𝐞 𝐫𝐞𝐥𝐢𝐞́𝐞 𝐚̀ 𝐭𝐨𝐧 𝐢𝐧𝐭𝐞́𝐠𝐫𝐚𝐭𝐢𝐨𝐧 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩.\n" +
      "╰━━━━━━━━━━━━━━━━━━╯"
    );
  }
};
