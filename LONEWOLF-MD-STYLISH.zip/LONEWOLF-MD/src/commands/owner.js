module.exports = {
  name: "owner",
  description: "Affiche les informations du propriétaire",
  execute: async ({ reply, config }) => {
    await reply(
      "╭━━〔 𝐎𝐖𝐍𝐄𝐑 〕━━╮\n" +
      "┃ 𝐏𝐫𝐨𝐩𝐫𝐢𝐞́𝐭𝐚𝐢𝐫𝐞 : " +
      (config.ownerNumber || "𝐍𝐨𝐧 𝐜𝐨𝐧𝐟𝐢𝐠𝐮𝐫𝐞́") +
      "\n" +
      "╰━━━━━━━━━━━━━━╯"
    );
  }
};
