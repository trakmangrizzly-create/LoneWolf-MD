module.exports = {
  name: "kick",
  description: "Commande réservée aux administrateurs du groupe",
  adminOnly: true,
  execute: async ({ reply }) => {
    await reply(
      "╭━━〔 𝐊𝐈𝐂𝐊 〕━━╮\n" +
      "┃ 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐞 𝐝𝐞́𝐭𝐞𝐜𝐭𝐞́𝐞.\n" +
      "┃ 𝐋𝐚 𝐥𝐨𝐠𝐢𝐪𝐮𝐞 𝐝'𝐞𝐱𝐩𝐮𝐥𝐬𝐢𝐨𝐧 𝐝𝐨𝐢𝐭 𝐞̂𝐭𝐫𝐞 𝐫𝐞𝐥𝐢𝐞́𝐞 𝐚̀ 𝐭𝐨𝐧 𝐢𝐧𝐭𝐞́𝐠𝐫𝐚𝐭𝐢𝐨𝐧 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩.\n" +
      "╰━━━━━━━━━━━━━━╯"
    );
  }
};
