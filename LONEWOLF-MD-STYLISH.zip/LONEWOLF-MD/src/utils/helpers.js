function normalizeText(text = "") {
  return String(text).trim();
}

function isPrefixedCommand(text, prefix = ".") {
  return normalizeText(text).startsWith(prefix);
}

module.exports = {
  normalizeText,
  isPrefixedCommand
};
