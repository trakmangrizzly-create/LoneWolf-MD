const { handleCommand } = require("./commands");
const config = require("../config/config");

async function handleMessage(message, reply, isAdmin = false) {
  const text = message?.text || "";
  return handleCommand({
    text,
    reply,
    config,
    isAdmin
  });
}

module.exports = { handleMessage };
