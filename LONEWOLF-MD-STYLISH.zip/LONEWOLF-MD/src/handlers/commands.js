const menu = require("../commands/menu");
const owner = require("../commands/owner");
const kick = require("../commands/kick");
const tagall = require("../commands/tagall");

const commands = new Map(
  [menu, owner, kick, tagall].map(command => [command.name, command])
);

async function handleCommand({ text, reply, config, isAdmin = false }) {
  const prefix = config.prefix;

  if (!text || !text.startsWith(prefix)) return false;

  const parts = text.slice(prefix.length).trim().split(/\s+/);
  const name = (parts.shift() || "").toLowerCase();
  const command = commands.get(name);

  if (!command) {
    await reply(`𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐞 𝐢𝐧𝐜𝐨𝐧𝐧𝐮𝐞. 𝐔𝐭𝐢𝐥𝐢𝐬𝐞 ${prefix}𝐦𝐞𝐧𝐮`);
    return true;
  }

  if (command.adminOnly && !isAdmin) {
    await reply("𝐂𝐞𝐭𝐭𝐞 𝐜𝐨𝐦𝐦𝐚𝐧𝐝𝐞 𝐞𝐬𝐭 𝐫𝐞́𝐬𝐞𝐫𝐯𝐞́𝐞 𝐚𝐮𝐱 𝐚𝐝𝐦𝐢𝐧𝐢𝐬𝐭𝐫𝐚𝐭𝐞𝐮𝐫𝐬.");
    return true;
  }

  await command.execute({ args: parts, reply, config });
  return true;
}

module.exports = { handleCommand, commands };
