require("dotenv").config();

module.exports = {
  botName: process.env.BOT_NAME || "LoneWolf-MD",
  prefix: process.env.PREFIX || ".",
  ownerNumber: process.env.OWNER_NUMBER || "",
  apiKey: process.env.API_KEY || ""
};
