const express = require("express");

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.json({
    bot: "LoneWolf-MD",
    status: "online",
    message: "API du bot opérationnelle"
  });
});

app.get("/api/status", (req, res) => {
  res.json({
    bot: "LoneWolf-MD",
    status: "online"
  });
});

module.exports = app;
