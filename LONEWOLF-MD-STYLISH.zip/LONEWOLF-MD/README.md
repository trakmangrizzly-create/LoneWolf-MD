# LONEWOLF-MD

Structure de base d'un bot/API compatible avec un déploiement Vercel.

## Commandes

- `.menu`
- `.owner`
- `.kick`
- `.tagall`

## Installation

```bash
npm install
npm start
```

## Variables d'environnement

Copier `.env.example` vers `.env` en développement et configurer les valeurs nécessaires.

Pour Vercel, ajouter les variables dans les Environment Variables du projet.

## Important

Cette base expose une API Express. Elle ne fournit pas à elle seule une connexion WhatsApp persistante 24h/24. Pour un véritable bot WhatsApp permanent, la couche de connexion/session doit être exécutée sur un hébergement adapté.
