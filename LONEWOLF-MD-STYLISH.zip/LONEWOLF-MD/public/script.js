async function checkStatus() {
  const output = document.getElementById("status");
  try {
    const response = await fetch("/api/status");
    const data = await response.json();
    output.textContent = JSON.stringify(data, null, 2);
  } catch (error) {
    output.textContent = "Erreur : " + error.message;
  }
}
